# Standalone detector regression harness

Use a .NET 9 SDK in a separate directory. This is validation code, not application source. The Harness project compiles the actual analysis/detector/share sources. Unchanged catalog JSON is a fixture; media/WinForms types and catalog access are lightweight fixture shells. No audio models or external NuGet packages are needed.

Run from the extracted root:

```text
dotnet run --project Harness/Harness.csproj -- source/league_aliases.json Harness/Roster.json /path/to/Game_5681318189_transcript.json /path/to/Game_5681318189_speaker_roles.json updated.json Harness/Cases.json
```

To reproduce baseline output use `-p:SourceRoot=../baseline`, set a separate output file, and omit the final Cases.json argument (the cases assert updated behavior). Roster.json is synthesized from the supplied match context, since parsed post-game data was not attached. The original source reproduces all 29 screenshot detections with this fixture. The app itself must still be built and run on Windows.
