using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace League_Data_Recorder;

// Platform/media shells are not exercised by the detector harness. The detector,
// finding/report types, ReadPlayers and speech allocation compile from production.
internal sealed class TranscriptionResult
{
    [JsonPropertyName("audio_timeline_shift_seconds")] public double AudioTimelineShiftSeconds { get; set; }
    [JsonPropertyName("words")] public List<WordResult> Words { get; set; } = new();
    public string JsonPath { get; set; } = "";
}
internal sealed class GameMediaTiming
{
    public bool VideoTrimmed { get; set; }
    public bool AudioTrimmed { get; set; }
    public double? GameStartClockSeconds { get; set; }
    public double? VideoFileStartClockSeconds { get; set; }
    public double? AlignedAudioFileStartClockSeconds { get; set; }
    public double? AudioFileStartClockSeconds { get; set; }
}
internal sealed class VideoReviewTiming
{
    public bool AudioAlignedToVideo { get; set; }
    public double AudioTimelineShiftSeconds { get; set; }
    public double AudioCorrectionSeconds { get; set; }
    public double CaptionCorrectionSeconds { get; set; }
    public static string PathFor(string path) => path + "_ReviewTiming.json";
    public static bool ValidCorrection(double value) => double.IsFinite(value);
}
internal static class VideoCommsTimeline
{
    internal static string NormalizeRole(string? role) => role?.ToLowerInvariant() switch
    {
        "top" => "top", "jungle" or "jg" or "jungler" => "jungle", "mid" or "middle" => "mid",
        "adc" or "bottom" or "bot" => "adc", "support" or "utility" or "supp" => "support",
        "coach" => "coach", "overlap" => "overlap", _ => "unknown"
    };
}

// Read the shipped alias JSON; unchanged catalog data is a fixture, not a second detector.
internal class AliasEntry
{
    public string Name { get; set; } = "";
    public string[] Aliases { get; set; } = [];
    public string[]? RoleAliases { get; set; }
}
internal sealed class ChampionAlias : AliasEntry { public int Id { get; set; } public string Key { get; set; } = ""; }
internal sealed class SummonerAlias : AliasEntry { public int Id { get; set; } }
internal sealed class AbilityAlias : AliasEntry { public int ChampionId { get; set; } public string Slot { get; set; } = ""; }
internal sealed class CatalogFile
{
    public ChampionAlias[] Champions { get; set; } = [];
    public SummonerAlias[] SummonerSpells { get; set; } = [];
    public AbilityAlias[] Abilities { get; set; } = [];
    public string[] IgnoreForRoleAssignment { get; set; } = [];
}
internal sealed class LeagueAliasCatalog
{
    private readonly CatalogFile data;
    internal LeagueAliasCatalog(string path) => data = JsonSerializer.Deserialize<CatalogFile>(File.ReadAllText(path),
        new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!;
    internal static string Key(string? value) => Regex.Replace(value?.ToLowerInvariant() ?? "", @"[^\p{L}\p{N}]", "");
    internal ChampionAlias? Champion(int? id, string? name = null) => data.Champions.FirstOrDefault(e => e.Id == id) ??
        data.Champions.FirstOrDefault(e => Key(e.Name) == Key(name) || Key(e.Key) == Key(name));
    internal SummonerAlias? Summoner(int? id, string? name = null) => data.SummonerSpells.FirstOrDefault(e => e.Id == id) ??
        data.SummonerSpells.FirstOrDefault(e => Key(e.Name) == Key(name) || e.Aliases.Any(a => Key(a) == Key(name)));
    internal IEnumerable<AbilityAlias> Abilities(int? championId) => data.Abilities.Where(a => a.ChampionId == championId);
    internal IEnumerable<string> Names(AliasEntry? entry, string? name) => new[] { name ?? "", entry?.Name ?? "" }
        .Concat(entry?.Aliases ?? []).Where(s => s.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase);
    internal IEnumerable<string> RoleNames(AliasEntry? entry, string? name) => new[] { name ?? "", entry?.Name ?? "" }
        .Concat(entry?.RoleAliases ?? entry?.Aliases ?? []).Where(s => s.Length > 0 &&
            !data.IgnoreForRoleAssignment.Any(ignore => Key(ignore) == Key(s))).Distinct(StringComparer.OrdinalIgnoreCase);
}

internal static partial class CommsAnalysis
{
    internal static List<CommsAnalysisFinding> TestDetect(List<WordResult> words, IReadOnlyDictionary<string,string> roles,
        LeagueAliasCatalog catalog, string rosterPath, double? offset = 0)
    {
        using var post = JsonDocument.Parse(File.ReadAllText(rosterPath));
        var players = ReadPlayers(post.RootElement, default, catalog);
        var calls = DetectCallouts(words, roles, players, catalog, offset, 2400, default);
        calls.AddRange(DetectObjectiveCalls(words, roles, offset));
        return calls.OrderBy(c => c.AudioSeconds).ThenBy(c => c.Category).ToList();
    }
    internal static object TestUtterances(List<WordResult> words) => DetectionUtterances(words)
        .Select(u => new { u.Start, u.End, u.Speaker, u.Text }).ToArray();
}
