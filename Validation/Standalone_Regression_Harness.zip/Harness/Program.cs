using System.Text.Json;
using League_Data_Recorder;

var json = new JsonSerializerOptions { PropertyNameCaseInsensitive = true, WriteIndented = true };
string fixture = Path.GetDirectoryName(Path.GetFullPath(args[0]))!;
var catalog = new LeagueAliasCatalog(args[0]);
string rosterPath = args[1];
using var savedRoles = JsonDocument.Parse(File.ReadAllText(args[3]));
var roles = savedRoles.RootElement.GetProperty("assignments").EnumerateObject().ToDictionary(x => x.Name, x => x.Value.GetString()!);
var transcript = JsonSerializer.Deserialize<TranscriptionResult>(File.ReadAllText(args[2]), json)!;
var findings = CommsAnalysis.TestDetect(transcript.Words, roles, catalog, rosterPath);
File.WriteAllText(args[4], JsonSerializer.Serialize(findings, json));
File.WriteAllText(args[4] + ".utterances.json", JsonSerializer.Serialize(CommsAnalysis.TestUtterances(transcript.Words), json));
Console.WriteLine(JsonSerializer.Serialize(new { findings = findings.Count,
    categories = findings.GroupBy(c => c.Category).ToDictionary(g => g.Key,g => g.Count()) }, json));
if (args.Length > 5)
{
    using var cases = JsonDocument.Parse(File.ReadAllText(args[5]));
    var results = new List<object>();
    int failed = 0;
    foreach (var test in cases.RootElement.EnumerateArray())
    {
        string name = test.GetProperty("name").GetString()!;
        var words = new List<WordResult>();
        double at = test.TryGetProperty("time", out var time) ? time.GetDouble() : 100;
        if (test.TryGetProperty("context", out var context))
            foreach (var span in context.EnumerateArray())
                words.AddRange(Words(span.GetProperty("text").GetString()!, span.GetProperty("speaker").GetString(), span.GetProperty("start").GetDouble()));
        string? speaker = test.TryGetProperty("speaker", out var who) ? who.GetString() : "speaker_1";
        words.AddRange(Words(test.GetProperty("text").GetString()!, speaker, at));
        double? offset = test.TryGetProperty("offset", out var shift) && shift.ValueKind == JsonValueKind.Null ? null : 0;
        var actual = CommsAnalysis.TestDetect(words, roles, catalog, rosterPath, offset).Where(f => f.AudioSeconds >= at).ToArray();
        var problems = new List<string>();
        if (test.TryGetProperty("count", out var count) && actual.Length != count.GetInt32())
            problems.Add($"Expected {count} findings, got {actual.Length}.");
        if (test.TryGetProperty("expected", out var expected))
            foreach (var pattern in expected.EnumerateArray())
                if (!actual.Any(a => Matches(a, pattern))) problems.Add("Missing: " + pattern.GetRawText());
        if (test.TryGetProperty("forbidden", out var forbidden))
            foreach (var pattern in forbidden.EnumerateArray())
                if (actual.Any(a => Matches(a, pattern))) problems.Add("Forbidden finding: " + pattern.GetRawText());
        if (problems.Count > 0) { failed++; Console.WriteLine("FAIL " + name + ": " + string.Join(" ", problems)); }
        results.Add(new { name, passed = problems.Count == 0, problems, actual });
    }
    File.WriteAllText(args[4] + ".tests.json", JsonSerializer.Serialize(results,json));
    Console.WriteLine($"Regression cases: {results.Count-failed}/{results.Count} passed.");
    if (failed > 0) Environment.ExitCode = 1;
}

static bool Matches(CommsAnalysisFinding finding, JsonElement expected)
{
    var actual = JsonSerializer.SerializeToElement(finding);
    return expected.EnumerateObject().All(p => actual.TryGetProperty(p.Name, out var v) && v.ToString() == p.Value.ToString());
}
static IEnumerable<WordResult> Words(string text, string? speaker, double start)
{
    var parts = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
    for (int i = 0; i < parts.Length; i++)
        yield return new WordResult { Word = " " + parts[i], Start = start + i * .18, End = start + i * .18 + .15, Speaker = speaker };
}
