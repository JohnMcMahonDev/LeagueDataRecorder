using System.Text.Json.Serialization;
namespace League_Data_Recorder;
public sealed class WordResult
{
    [JsonPropertyName("start")]
    public double Start { get; set; }

    [JsonPropertyName("end")]
    public double End { get; set; }

    [JsonPropertyName("word")]
    public string Word { get; set; } = string.Empty;

    [JsonPropertyName("probability")]
    public double? Probability { get; set; }

    [JsonPropertyName("speaker")]
    public string? Speaker { get; set; }

    [JsonPropertyName("speaker_source")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? SpeakerSource { get; set; }

    [JsonPropertyName("timing_source")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? TimingSource { get; set; }

    [JsonPropertyName("alignment_confidence")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public double? AlignmentConfidence { get; set; }

    [JsonPropertyName("dtw_first_token_time")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public double? DtwFirstTokenTime { get; set; }

    [JsonPropertyName("dtw_last_token_time")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public double? DtwLastTokenTime { get; set; }

    [JsonPropertyName("dtw_fallback_reason")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? DtwFallbackReason { get; set; }

    [JsonPropertyName("overlapping_speech")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public bool OverlappingSpeech { get; set; }

    // Ranked by simultaneous RTTM coverage, not a probability or a text attribution.
    [JsonPropertyName("overlapping_speakers")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string[]? OverlappingSpeakers { get; set; }
}
