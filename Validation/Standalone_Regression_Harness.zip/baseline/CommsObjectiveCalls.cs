using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace League_Data_Recorder;

internal static partial class CommsAnalysis
{
    internal const string ObjectiveCountingRule = "Objective calls: explicit team instructions to contest, take, give, defend, push, set up or end, with a named objective or clear end-game route. Negation is preserved. Same-caller repeats of the same instruction/target within 4s form one call; a changed instruction counts separately. Questions, enemy reports, counterfactuals, uncertain alternatives and bare objective/timer mentions are excluded. Counts describe calls, not whether they were followed or succeeded.";

    // Keep the grammar explicit: a nearby objective noun alone is not a call.
    internal const string ObjectiveActionPattern = @"\b(?:fight(?:ing)?|contest(?:ing)?|tak(?:e|ing)|start(?:ing)?|do(?:ing)?|hit(?:ting)?|burn(?:ing)?|rush(?:ing)?|secur(?:e|ing)|finish(?:ing)?|steal(?:ing)?|get(?:ting)?|giv(?:e|ing)(?:\s+up)?|conced(?:e|ing)|leav(?:e|ing)|drop(?:ping)?|defend(?:ing)?|hold(?:ing)?|sav(?:e|ing)|protect(?:ing)?|push(?:ing)?|sieg(?:e|ing)|set(?:ting)?\s+up|setup|prep(?:ping)?|prepar(?:e|ing)|group(?:ing)?|rotat(?:e|ing)|end(?:ing)?)\b";
    internal const string ObjectiveEpicPattern = @"\b(?:elder(?:\s+(?:dragon|drake))?|dragon|drake|baron(?:\s+nashor)?|nashor|nash|rift\s+herald|herald|void\s*grubs|grubs|atakhan)\b";
    private const string ObjectiveLanePattern = @"(?:top|mid|middle|bot|bottom)";
    private const string ObjectiveTierPattern = @"(?:t\s*(?:[123]|one|two|three)|tier\s*(?:[123]|one|two|three)|outer|inner|first|second|third)";
    private const string ObjectiveStructurePattern = @"(?:inhib(?:itor)?\s+(?:tower|turret)s?|nexus\s+(?:tower|turret)s?|tower[s]?|turret[s]?|inhib(?:itor)?s?|nexus|base)";
    internal const string ObjectiveBuildingPattern = @"\b(?:" +
        @"(?<tier1>" + ObjectiveTierPattern + @")\s+(?<lane1>" + ObjectiveLanePattern + @")\s+(?<structure1>" + ObjectiveStructurePattern + @")|" +
        @"(?<lane2>" + ObjectiveLanePattern + @")\s+(?<tier2>" + ObjectiveTierPattern + @")(?:\s+(?<structure2>tower[s]?|turret[s]?))?|" +
        @"(?:(?<lane3>" + ObjectiveLanePattern + @")\s+)?(?:(?<tier3>" + ObjectiveTierPattern + @")\s+)?(?<structure3>" + ObjectiveStructurePattern + @")|" +
        @"(?<tier4>t\s*(?:[123]|one|two|three)|tier\s*(?:[123]|one|two|three))" +
        @")(?:\s+(?:(?:in|at|on)\s+)?(?<postLane>" + ObjectiveLanePattern + @"))?\b";
    internal const string ObjectiveLeadPattern = @"^\s*(?:(?:yeah|yes|okay|ok|alright|wait|no|guys|team|please|just|so|then|now|actually|go)[,\s]+)*" +
        @"(?:(?:i\s+think\s+)?(?:let's|lets|let\s+us|we(?:'re|\s+are)?|you|i(?:'ll|'m|\s+am)?)\s+)?" +
        @"(?:(?:can|should|must|will|are|be|need\s+to|have\s+to|gotta|want\s+to|wanna|going\s+to|gonna|all|just|still|really|definitely)\s+)*" +
        @"(?:(?:don't|dont|do\s+not|not|never|can't|cannot|won't|shouldn't|aren't)\s+)?$";
    internal const string ObjectiveBridgePattern = @"^[,\s]*(?:(?:the|a|an|our|their|this|that|these|those|next|first|second|third|all|both|it|them|us|for|at|on|to|around|down|up|through|and|then|just|now)\b[\s,]*)*$";
    internal const string ObjectiveNonCallPattern = @"^\s*(?:can|could|should|would|why|how|what|when|where|who|is|are|was|were)\b|^\s*(?:do|does|did)\s+(?:we|you|i|they|he|she|it)\b|\b(?:if|unless|whether|maybe|perhaps|might|could|would|said|told)\b|\bshould\s+have\b";
    private sealed record ObjectiveTarget(string Key, string Label, string Kind, int Index, int Length);
    private sealed record ObjectiveIntent(string Code, string Label);
    private sealed record ObjectiveRepeat(string Action, double LastSeen, CommsAnalysisFinding Finding);

    internal static List<CommsAnalysisFinding> DetectObjectiveCalls(IEnumerable<WordResult> words,
        IReadOnlyDictionary<string, string> roles, double? audioToGame = null, CancellationToken token = default)
    {
        var found = new List<CommsAnalysisFinding>();
        var recent = new Dictionary<string, ObjectiveRepeat>(StringComparer.Ordinal);
        foreach (var u in ObjectiveUtterances(words))
        {
            token.ThrowIfCancellationRequested();
            // Only unfinished fragments are joined below. Replacing their ASR
            // punctuation with spaces preserves character positions for u.At().
            string text = u.Text.Replace('.', ' ').Replace('!', ' ');
            if (u.Text.Contains('?') || Regex.IsMatch(text, ObjectiveNonCallPattern, Rx)) continue;
            var actions = Regex.Matches(text, ObjectiveActionPattern, Rx).Cast<Match>().ToArray();
            bool previousAccepted = false;
            for (int i = 0; i < actions.Length; i++)
            {
                var action = actions[i];
                var intent = ObjectiveAction(action.Value);
                string before = text[..action.Index];
                var boundaries = Regex.Matches(before, @"[,;]|\b(?:and|but|then|while|instead)\b", Rx).Cast<Match>().ToArray();
                int boundary = boundaries.Length > 0 ? boundaries[^1].Index + boundaries[^1].Length : 0;
                string lead = text[boundary..action.Index];
                bool accepted = Regex.IsMatch(lead, ObjectiveLeadPattern, Rx);
                if (!accepted && i > 0 && previousAccepted && boundary <= actions[i - 1].Index)
                {
                    // ASR may omit the comma in 'give dragon, take mid tower'.
                    // Inherit only after an explicit objective, never arbitrary speech.
                    string remainder = text[(actions[i - 1].Index + actions[i - 1].Length)..action.Index];
                    var previousTargets = ObjectiveTargets(remainder);
                    foreach (var t in previousTargets.OrderByDescending(t => t.Index))
                        remainder = remainder.Remove(t.Index, t.Length).Insert(t.Index, new string(' ', t.Length));
                    if (previousTargets.Count > 0 && Regex.IsMatch(remainder, ObjectiveBridgePattern, Rx))
                    { lead = ""; accepted = true; }
                }
                // A coordinated enemy report is still an enemy report: 'they
                // take dragon and push mid tower' must not become our instruction.
                if (i > 0 && !previousAccepted && !Regex.IsMatch(lead, @"\b(?:we|you|i|let's|lets|let\s+us)\b", Rx)) accepted = false;
                int end = i + 1 < actions.Length ? actions[i + 1].Index : text.Length;
                var targets = ObjectiveTargets(text[(action.Index + action.Length)..end])
                    .Select(t => t with { Index = t.Index + action.Index + action.Length }).ToList();
                // Explicit topic-first phrasing, such as 'dragon, we give'. Do
                // not borrow an objective from a preceding, complete instruction.
                if (i == 0 && targets.Count == 0)
                {
                    var topic = ObjectiveTargets(before).LastOrDefault();
                    if (topic is not null && (before[(topic.Index + topic.Length)..].Contains(',') ||
                        Regex.IsMatch(before[(topic.Index + topic.Length)..], @"\b(?:we|you|i|let's|lets)\b", Rx)) &&
                        Regex.IsMatch(text[(action.Index + action.Length)..end], ObjectiveBridgePattern, Rx) &&
                        Regex.IsMatch(before[(topic.Index + topic.Length)..], @"^[,\s]*(?:" + ObjectiveLeadPattern[1..^1] + @")$", Rx))
                    {
                        targets.Add(topic);
                        lead = before[(topic.Index + topic.Length)..].TrimStart(',', ' ');
                        accepted = Regex.IsMatch(lead, ObjectiveLeadPattern, Rx);
                    }
                }
                previousAccepted = accepted;
                if (!accepted || Regex.IsMatch(text[(action.Index + action.Length)..end], @"\bor\b", Rx)) continue;
                bool negative = Regex.IsMatch(lead, @"\b(?:don't|dont|do\s+not|not|never|can't|cannot|won't|shouldn't|aren't)\b", Rx);
                string code = (negative ? "avoid_" : "") + intent.Code;
                int previousTargetEnd = action.Index + action.Length;
                foreach (var target in targets.OrderBy(t => t.Index))
                {
                    string bridge = target.Index >= previousTargetEnd ? text[previousTargetEnd..target.Index] : "";
                    if (!Regex.IsMatch(bridge, ObjectiveBridgePattern, Rx) || Regex.Matches(bridge, @"\b\w+\b").Count > 8) continue;
                    if (intent.Code == "push" && target.Kind == "epic" || intent.Code == "end" && target.Kind is not ("base" or "nexus")) continue;
                    Add(target, code, negative ? "Don't " + intent.Label.ToLowerInvariant() : intent.Label);
                    previousTargetEnd = Math.Max(previousTargetEnd, target.Index + target.Length);
                }
                if (intent.Code == "end" && targets.Count == 0)
                {
                    string rest = text[(action.Index + action.Length)..end];
                    rest = Regex.Replace(rest, @"(?:,\s*|\b(?:and|but|then|while)\s*)+$", "", Rx);
                    var route = Regex.Match(rest, @"^\s*(?:(?:the|this)\s+game|it)?\s*(?:(?:through|via|down)\s+(?<lane>top|mid|middle|bot|bottom)|(?<directLane>top|mid|middle|bot|bottom))?\s*(?:now|here|just)?\s*$", Rx);
                    if (route.Success)
                    {
                        string lane = ObjectiveLane(route.Groups["lane"].Value.Length > 0 ? route.Groups["lane"].Value : route.Groups["directLane"].Value);
                        string label = lane.Length > 0 ? "through " + lane : "the game";
                        Add(new("nexus:" + lane + "::", label, "nexus", action.Index + action.Length, route.Length), code,
                            negative ? "Don't end" : "End");
                    }
                }

                void Add(ObjectiveTarget target, string actionCode, string actionLabel)
                {
                    var attribution = CallSpeaker(u, roles);
                    // In 'take dragon and baron', the second explicit target is
                    // called when its name is spoken, not at the earlier verb.
                    int anchor = previousTargetEnd > action.Index + action.Length && target.Index >= previousTargetEnd
                        ? target.Index : action.Index;
                    double at = u.At(anchor).Word.Start;
                    double lastWord = u.At(Math.Max(action.Index, Math.Min(text.Length - 1, target.Index + target.Length - 1))).Word.End;
                    string identity = u.Identity.Length > 0 ? u.Identity : "unknown";
                    string key = identity + "|" + target.Key;
                    if (recent.TryGetValue(key, out var prior) && prior.Action == actionCode && at >= prior.LastSeen && at - prior.LastSeen <= RepeatSeconds)
                    {
                        prior.Finding.AudioEndSeconds = Math.Max(prior.Finding.AudioEndSeconds ?? prior.Finding.AudioSeconds, lastWord);
                        if (!prior.Finding.Text.Contains(u.Text, StringComparison.Ordinal)) prior.Finding.Text += "\n" + u.Text;
                        recent[key] = prior with { LastSeen = at };
                        return;
                    }
                    var finding = new CommsAnalysisFinding
                    {
                        Id = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("objective|" + key + "|" + actionCode + "|" + at.ToString("R", CultureInfo.InvariantCulture))))[..24],
                        AudioSeconds = at, AudioEndSeconds = Math.Max(at, lastWord),
                        GameSeconds = audioToGame.HasValue ? at + audioToGame.Value : null,
                        Category = "Objective", Scope = "Team", Role = attribution.Role, SpeakerId = u.Speaker,
                        SpeakerAttribution = attribution.Method, Subject = actionLabel + " " + target.Label, Target = target.Label,
                        Call = actionLabel, CallKind = actionCode, Text = u.Text, UsesCollapsedTiming = u.Collapsed,
                        TargetResolution = "Explicit objective instruction", Uncertain = Regex.IsMatch(lead, @"\b(?:think|should)\b", Rx),
                        Evidence = "An explicit team instruction and objective were stated. Repeats from the same caller within 4s count once; changed instructions remain separate. Speaker attribution: " + attribution.Method + ". This does not verify whether the call was followed or succeeded.",
                    };
                    found.Add(finding);
                    recent[key] = new(actionCode, at, finding);
                }
            }
        }
        return found.OrderBy(f => f.AudioSeconds).ThenBy(f => f.Id, StringComparer.Ordinal).ToList();
    }

    private static List<Utterance> ObjectiveUtterances(IEnumerable<WordResult> words)
    {
        var result = new List<Utterance>();
        foreach (var speaker in DetectionUtterances(words).GroupBy(u => u.Speaker, StringComparer.Ordinal))
        {
            Utterance? current = null;
            foreach (var next in speaker.OrderBy(u => u.Start))
            {
                bool incomplete = current is not null && !current.Text.Contains('?') && Regex.IsMatch(current.Text,
                    @"\b(?:fight|contest|give|take|start|do|hit|burn|rush|secure|finish|steal|get|defend|hold|save|protect|siege|push|end|set\s+up|group|rotate|top|mid|bot|bottom|don't|dont|do\s+not|not)(?:\s+(?:the|a|our|their|this|that|for|at|to|through|up))*[.!]?\s*$", Rx);
                if (incomplete && current is not null && next.Start >= current.End - .05 && next.Start - current.End <= FragmentGapSeconds && next.End - current.Start <= 12)
                    current = new Utterance { Tokens = current.Tokens.Concat(next.Tokens).OrderBy(t => t.Word.Start).ThenBy(t => t.Order).ToList() };
                else { if (current is not null) result.Add(current); current = next; }
            }
            if (current is not null) result.Add(current);
        }
        return result.OrderBy(u => u.Start).ToList();
    }

    private static ObjectiveIntent ObjectiveAction(string verb)
    {
        string value = verb.ToLowerInvariant();
        if (Regex.IsMatch(value, @"^(?:fight|contest)")) return new("contest", "Contest");
        if (Regex.IsMatch(value, @"^(?:giv|conced|leav|drop)")) return new("give", "Give");
        if (Regex.IsMatch(value, @"^(?:defend|hold|sav|protect)")) return new("defend", "Defend");
        if (Regex.IsMatch(value, @"^(?:push|sieg)")) return new("push", "Push");
        if (Regex.IsMatch(value, @"^(?:set|prep|group|rotat)")) return new("setup", "Set up");
        return value.StartsWith("end", StringComparison.Ordinal) ? new("end", "End") : new("take", "Take");
    }

    private static List<ObjectiveTarget> ObjectiveTargets(string text)
    {
        var result = new List<ObjectiveTarget>();
        foreach (Match m in Regex.Matches(text, ObjectiveEpicPattern, Rx))
        {
            string value = m.Value.ToLowerInvariant();
            string label = value.StartsWith("elder", StringComparison.Ordinal) ? "elder" :
                Regex.IsMatch(value, @"^(?:dragon|drake)$") ? "dragon" : Regex.IsMatch(value, @"^(?:baron|nash)") ? "baron" :
                value.Contains("herald", StringComparison.Ordinal) ? "herald" : value.Contains("grub", StringComparison.Ordinal) ? "grubs" : "atakhan";
            result.Add(new("epic:" + label, label, "epic", m.Index, m.Length));
        }
        foreach (Match m in Regex.Matches(text, ObjectiveBuildingPattern, Rx))
        {
            string Group(params string[] names) => names.Select(n => m.Groups[n].Value).FirstOrDefault(v => v.Length > 0) ?? "";
            string lane = ObjectiveLane(Group("lane1", "lane2", "lane3", "postLane"));
            string postLane = ObjectiveLane(m.Groups["postLane"].Value);
            if (lane.Length > 0 && postLane.Length > 0 && lane != postLane) continue;
            string structure = Group("structure1", "structure2", "structure3").ToLowerInvariant();
            string tier = ObjectiveTier(Group("tier1", "tier2", "tier3", "tier4"));
            bool tower = structure.Contains("tower", StringComparison.Ordinal) || structure.Contains("turret", StringComparison.Ordinal) || tier.Length > 0;
            string kind = structure.StartsWith("nexus", StringComparison.Ordinal) ? "nexus" : structure == "base" ? "base" : tower ? "tower" : "inhibitor";
            if (tower && structure.StartsWith("inhib", StringComparison.Ordinal) && tier.Length == 0) tier = "T3";
            string label = kind == "nexus" ? structure.Contains(' ') ? "nexus towers" : "nexus" : kind == "base" ? "base" :
                (lane.Length > 0 ? lane + " " : "") + (kind == "inhibitor" ? "inhibitor" : tier.Length > 0 ? tier + (lane.Length == 0 ? " tower" : "") : "tower");
            result.Add(new(kind + ":" + lane + ":" + tier + ":" + (structure.StartsWith("nexus ", StringComparison.Ordinal) ? "towers" : ""), label, kind, m.Index, m.Length));
        }
        return result.OrderBy(t => t.Index).ToList();
    }
    private static string ObjectiveLane(string value) => value.ToLowerInvariant() switch { "middle" => "mid", "bottom" => "bot", var v => v };
    private static string ObjectiveTier(string value)
    {
        if (value.Length == 0) return "";
        if (Regex.IsMatch(value, @"(?:1|one|first|outer)\b", Rx)) return "T1";
        return Regex.IsMatch(value, @"(?:2|two|second|inner)\b", Rx) ? "T2" : "T3";
    }
}
