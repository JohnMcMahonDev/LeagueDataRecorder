using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace League_Data_Recorder;

internal static partial class CommsAnalysis
{
    // Time limits describe conversational continuity, not a desired count or game-specific calibration.
    private const double ContextSeconds = 8, RepeatSeconds = 4, FragmentGapSeconds = 1.6;
    private sealed record SpeechToken(WordResult Word, int Order)
    {
        internal string Text => Word.Word.Trim();
        internal string Speaker => Word.Speaker ?? "";
    }
    private sealed class Utterance
    {
        internal List<SpeechToken> Tokens = new();
        internal string Text => string.Join(" ", Tokens.Select(t => t.Text)).Replace('’', '\'');
        internal double Start => Tokens[0].Word.Start;
        internal double End => Tokens.Max(t => t.Word.End);
        internal string[] Speakers => Tokens.Select(t => t.Speaker).Where(s => !UnknownSpeaker(s)).Distinct(StringComparer.Ordinal).ToArray();
        internal string Speaker => Speakers.Length == 1 ? Speakers[0] : "";
        internal string Identity => string.Join("|", Speakers.OrderBy(s => s, StringComparer.Ordinal));
        internal SpeechToken At(int index)
        {
            int length = 0;
            foreach (var t in Tokens) { length += t.Text.Length + 1; if (length > index) return t; }
            return Tokens[^1];
        }
        internal bool Collapsed => Tokens.Any(t => t.Word.End <= t.Word.Start);
        internal bool Overlap => Tokens.Any(t => t.Word.OverlappingSpeech);
    }
    private sealed record Mention(Player Player, int Index, int Length, double Time, string Source);
    private sealed record Focus(Player Player, double Time, double End, string Text, string Speaker);
    private sealed record LaneFocus(string Role, double Time, string Text);
    private sealed record Resolution(Player Player, string Method, string Evidence, double AnchorTime, bool IsSelf = false);
    private sealed record CallState(string Kind, string Label, double? Seconds = null);
    private sealed record SpellMention(Match Match, string Category, string Name, bool NeedsContext, bool Bundle = false, Player? AbilityOwner = null);

    private static bool UnknownSpeaker(string? speaker) => string.IsNullOrWhiteSpace(speaker) ||
        speaker.Equals("unknown", StringComparison.OrdinalIgnoreCase) || speaker.Equals("unassigned", StringComparison.OrdinalIgnoreCase);
    private static bool DetectionWord(WordResult w) => w is not null && w.SpeakerSource != "asr_gap" &&
        !string.IsNullOrWhiteSpace(w.Word) && w.Word.Any(char.IsLetterOrDigit) &&
        double.IsFinite(w.Start) && double.IsFinite(w.End) && w.Start >= 0 && w.End >= w.Start;

    private static List<Utterance> DetectionUtterances(IEnumerable<WordResult> words)
    {
        var result = new List<Utterance>();
        // The retained word speaker is useful for sentence reconstruction even when the word overlaps.
        // It is not used to give the same callout to two candidate speakers.
        var tokens = words.Select((w, i) => new SpeechToken(w, i)).Where(t => DetectionWord(t.Word));
        foreach (var speaker in tokens.GroupBy(t => t.Speaker, StringComparer.Ordinal))
        {
            var span = new Utterance();
            foreach (var t in speaker.OrderBy(t => t.Word.Start).ThenBy(t => t.Order))
            {
                if (span.Tokens.Count > 0 && (t.Word.Start - span.End > 2 || t.Word.End - span.Start > 12))
                { result.Add(span); span = new(); }
                span.Tokens.Add(t);
                if (Regex.IsMatch(t.Text, @"[.!?]$")) { result.Add(span); span = new(); }
            }
            if (span.Tokens.Count > 0) result.Add(span);
        }
        return result.OrderBy(u => u.Start).ThenBy(u => u.Tokens[0].Order).ToList();
    }

    private static bool Question(string text) => text.Contains('?') || Regex.IsMatch(text,
        @"^\s*(?:(?:yeah|okay|ok|wait)[, ]+)*(?:does|do|did|can|could|should|would|where|when|who|is|are|was|were)\b", Rx);
    private static string Phrase(string phrase) => @"(?<![\p{L}\p{N}])" + Regex.Escape(phrase).Replace(@"\ ", @"\s+") + @"(?![\p{L}\p{N}])";
    private static bool AmbiguousAlias(string alias, List<Player> players, Player target) =>
        players.Any(p => p != target && p.Aliases.Any(a => a.Equals(alias, StringComparison.OrdinalIgnoreCase)));
    private static string PlayerKey(Player p) => p.Team + "|" + p.ChampionId + "|" + p.Name + "|" + p.Champion;

    private static List<Mention> Mentions(Utterance u, List<Player> players)
    {
        var found = new List<Mention>();
        string text = u.Text;
        foreach (var p in players)
        {
            var names = p.Aliases.Concat(p.Name.Length > 0 ? new[] { p.Name.Split('#')[0] } : []).Distinct(StringComparer.OrdinalIgnoreCase);
            foreach (string name in names)
                foreach (Match m in Regex.Matches(text, Phrase(name), Rx))
                {
                    // A mirror pick needs an explicit side qualifier; never guess which copy was meant.
                    bool ambiguous = players.Any(other => other != p && (other.Aliases.Any(a => a.Equals(name, StringComparison.OrdinalIgnoreCase)) ||
                        other.Name.Length > 0 && other.Name.Split('#')[0].Equals(name, StringComparison.OrdinalIgnoreCase)));
                    if (ambiguous)
                    {
                        string before = text[Math.Max(0, m.Index - 18)..m.Index];
                        bool? side = Regex.IsMatch(before, @"\b(?:enemy|their|opposing)\s*$", Rx) ? false :
                            Regex.IsMatch(before, @"\b(?:our|allied)\s*$", Rx) ? true : null;
                        if (side is null || p.Ally != side) continue;
                    }
                    found.Add(new(p, m.Index, m.Length, u.At(m.Index).Word.Start, m.Value));
                }
        }
        foreach (Match m in Regex.Matches(text, @"\b(?<side>enemy|their|opposing|our|allied)\s+(?<role>top|jungler|jungle|jg|mid|adc|ad carry|support|supp)\b", Rx))
        {
            bool ally = Regex.IsMatch(m.Groups["side"].Value, @"^(?:our|allied)$", Rx);
            string role = RoleReference(m.Groups["role"].Value);
            var candidates = players.Where(p => p.Ally == ally && p.Role == role).ToArray();
            if (candidates.Length == 1) found.Add(new(candidates[0], m.Index, m.Length, u.At(m.Index).Word.Start, m.Value));
            else if (candidates.Length == 0 && !ally && role == "jungle")
                found.Add(new(new Player { Champion = "Enemy jungler", Role = "jungle", Ally = false, Team = -1, Generic = true }, m.Index, m.Length, u.At(m.Index).Word.Start, m.Value));
        }
        return found.GroupBy(m => (PlayerKey(m.Player), m.Index)).Select(g => g.OrderByDescending(m => m.Length).First())
            .OrderBy(m => m.Index).ToList();
    }
    private static string RoleReference(string role) => role.ToLowerInvariant() switch
    { "jg" or "jungler" => "jungle", "ad carry" => "adc", "supp" => "support", var value => value };

    private static IEnumerable<SpellMention> SpellMentions(string text, List<Player> players, LeagueAliasCatalog catalog)
    {
        foreach (var spell in Spells)
            foreach (Match m in Regex.Matches(text, spell.Pattern, Rx)) yield return new(m, "Summoner", spell.Name, spell.NeedsContext);
        foreach (Match m in Regex.Matches(text, @"\b(?:sums|summs|summoners?(?:\s+spells?)?)\b", Rx))
            yield return new(m, "Summoner", "Summoner spells", false, true);
        foreach (Match m in Regex.Matches(text, @"\b(?:ult(?:imates?|i|ed|ing|s)?|ulti|r)\b", Rx))
            yield return new(m, "Ultimate", "Ultimate", false);
        var abilityNames = players.SelectMany(p =>
        {
            var ult = catalog.Abilities(p.ChampionId).FirstOrDefault(a => a.Slot == "R");
            return catalog.Names(ult, ult?.Name).Where(n => n.Length >= 4).Select(n => (Player: p, Name: n));
        }).GroupBy(a => a.Name, StringComparer.OrdinalIgnoreCase);
        foreach (var name in abilityNames)
            foreach (Match m in Regex.Matches(text, Phrase(name.Key), Rx))
                yield return new(m, "Ultimate", "Ultimate", false, false, name.Count() == 1 ? name.First().Player : null);
    }

    private static (int Start, int End) ClauseBounds(string text, Match m)
    {
        var punctuation = Regex.Matches(text, @"(?<!\d)\.|\.(?!\d)|[!?;]").Cast<Match>().ToArray();
        int left = punctuation.Where(p => p.Index < m.Index).Select(p => p.Index + p.Length).DefaultIfEmpty(0).Last();
        int end = punctuation.Where(p => p.Index >= m.Index + m.Length).Select(p => p.Index + p.Length).DefaultIfEmpty(text.Length).First();
        // A comma is a clause boundary only if the following words introduce a new subject/question.
        int originalLeft = left;
        foreach (Match split in Regex.Matches(text[originalLeft..end], @",\s*(?=(?:i|he|she|they|we|you|can|could|does|is|where)\b)", Rx))
        {
            int at = originalLeft + split.Index;
            if (at < m.Index) left = at + split.Length;
            else { end = at; break; }
        }
        return (left, end);
    }

    private static CallState? State(string text, SpellMention spell, string clause, string before, string after)
    {
        if (Question(clause) || Regex.IsMatch(clause, @"^\s*(?:(?:yeah|well|okay|oh)[, ]+)*if\b", Rx)) return null;
        if (Regex.IsMatch(before, @"\b(?:will|would|should|could|can|gonna|going to|want to|wanna|don't|do not|hasn't|has not|haven't|have not|never)\s+(?:(?:use|cast)\s+)?$", Rx)) return null;
        if (Regex.IsMatch(before, @"\b(?:nice|good|great|celebratory)\s*$", Rx)) return null;
        var clock = Regex.Match(after, @"^\s+(?:(?:is|back|up|ready)\s+)*(?:at\s+)?(?<m>\d{1,2}):(?<s>[0-5]\d)\b", Rx);
        if (clock.Success) return new("clock", "Timer " + clock.Groups["m"].Value + ":" + clock.Groups["s"].Value,
            int.Parse(clock.Groups["m"].Value, CultureInfo.InvariantCulture) * 60 + int.Parse(clock.Groups["s"].Value, CultureInfo.InvariantCulture));
        var remaining = Regex.Match(after, @"^\s+(?:(?:is|back|up|ready|comes?\s+back)\s+)*(?:in|on)\s+(?<n>\d+(?:\.\d+)?)\s*(?<unit>seconds?|secs?|s|minutes?|mins?|m)?\b", Rx);
        if (remaining.Success && double.TryParse(remaining.Groups["n"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out double n))
        {
            bool minutes = remaining.Groups["unit"].Value.StartsWith("m", StringComparison.OrdinalIgnoreCase);
            double seconds = n * (minutes ? 60 : 1);
            if (seconds is >= 0 and <= 600) return new("cooldown", "Back in " + seconds.ToString("0.##", CultureInfo.InvariantCulture) + "s", seconds);
        }
        if (Regex.IsMatch(before, @"\b(?:no|without|(?:doesn't|does not|don't|do not|didn't|did not)\s+have)\s+(?:(?:his|her|their|my|any)\s+)?$", Rx) ||
            Regex.IsMatch(after, @"^\s+(?:(?:is|was)\s+)?(?:down|on cooldown|not (?:up|ready|available))\b", Rx)) return new("unavailable", "Unavailable");
        if (Regex.IsMatch(before, @"\b(?:not|never|didn't|did not|wasn't|was not|isn't|is not)\s*$", Rx) ||
            Regex.IsMatch(before, @"\b(?:should|could|would|might)\s+have\s*$", Rx)) return null;
        bool reportedUse = Regex.IsMatch(spell.Match.Value, @"(?:ed|ing)$", Rx) ||
            Regex.IsMatch(before, @"\b(?:used|missed|wasted|burned|burnt|blew|popped|cast|had to)\s+(?:(?:his|her|their|my|an?|the)\s+)?$", Rx) ||
            Regex.IsMatch(after, @"^\s+(?:used|burned|burnt)\b", Rx);
        if (reportedUse && (Regex.IsMatch(before, @"\b(?:should|could|would|might)\s+have(?:\s+(?:just|already|used|cast|wasted|missed|my|his|her|their|an?|the))*\s*$", Rx) ||
            Regex.IsMatch(before, @"\b(?:will|gonna|going to|want to|wanna|need to|don't|do not)\s+(?:(?:use|cast|my|his|her|their|an?|the)\s+)*$", Rx) ||
            Regex.IsMatch(clause, @"^\s*(?:please\s+)?cast\b", Rx))) return null;
        if (reportedUse) return new("used", "Used");
        if (Regex.IsMatch(before, @"\b(?:has|have|got|i've got)\s+(?:(?:his|her|their|my|another|all|both|an?|the|still|already)\s+)*$", Rx) ||
            Regex.IsMatch(after, @"^\s+(?:(?:is|was)\s+)?(?:up|ready|back|available)\b", Rx)) return new("available", "Available");
        return null;
    }

    private static List<Utterance> JoinFragments(List<Utterance> input, List<Player> players)
    {
        var output = new List<Utterance>();
        for (int i = 0; i < input.Count; i++)
        {
            var a = input[i];
            while (i + 1 < input.Count)
            {
                var b = input[i + 1];
                string first = a.Text.TrimEnd('.', ',', ';');
                var names = Mentions(a, players);
                bool incomplete = Regex.IsMatch(first, @"(?:^|\s)(?:i|no|is|has|have|doesn't|does not|don't|do not)$", Rx) ||
                    names.Count > 0 && first.Length <= names.Max(n => n.Index + n.Length) + 1 ||
                    Regex.IsMatch(first, @"\b(?:top|bot|bottom)$", Rx) && Regex.IsMatch(b.Text, @"^side\b", Rx);
                bool continuation = Regex.IsMatch(b.Text, @"^\s*(?:have|has|no|not|r\b|ult\b|flash\b|(?:should|might|may|could|must|will)\s+(?:be|open|go|come|head|move|roam)|is\b|was\b|helping\b|top\b|bot\b|mid\b|side\b)", Rx);
                if (incomplete && continuation && !Question(a.Text) && Mentions(b, players).Count == 0 &&
                    b.Start >= a.End - .05 && b.Start - a.End <= FragmentGapSeconds && b.End - a.Start <= 12)
                {
                    a = new Utterance { Tokens = a.Tokens.Concat(b.Tokens).OrderBy(t => t.Word.Start).ThenBy(t => t.Order).ToList() };
                    i++;
                }
                else break;
            }
            output.Add(a);
        }
        return output;
    }

    private static Resolution? Resolve(Utterance u, Match match, (int Start, int End) bounds, List<Mention> mentions,
        List<Player> players, IReadOnlyDictionary<string, string> roles, List<Focus> history,
        Dictionary<string, (Resolution Resolution, double Last)> subjects, List<LaneFocus> lanes, Player? abilityOwner = null)
    {
        string text = u.Text, clause = text[bounds.Start..bounds.End];
        string before = text[bounds.Start..match.Index];
        double at = u.At(match.Index).Word.Start;
        bool self = Regex.IsMatch(before, @"\bmy\s*$|\bi(?:'ve|'m| am)?\s+(?:(?:just|already|still|another|had|to|have|got|used|missed|wasted|burned|burnt|cast|no|not|don't|do not|an?|the)\s+)*$", Rx);
        if (self)
        {
            string role = CommsSpeechIntervals.AssignedRole(u.Speaker, roles);
            var own = players.Where(p => p.Ally == true && p.Role == role && role != "unknown").ToArray();
            return own.Length == 1 ? new(own[0], "self", "Explicit first-person ownership and saved speaker role.", at, true) : null;
        }
        int entityEnd = bounds.End;
        var followingClause = Regex.Match(text[(match.Index + match.Length)..bounds.End],
            @"\b(?:if|when|unless|because|but)\b|\band\s+(?=(?:we|they|i|he|she|you)\b)", Rx);
        if (followingClause.Success) entityEnd = match.Index + match.Length + followingClause.Index;
        var local = mentions.Where(m => m.Index >= bounds.Start && m.Index < entityEnd).ToArray();
        bool thirdPersonCast = Regex.IsMatch(before, @"\b(?:he|she|they)\b", Rx) &&
            (Regex.IsMatch(match.Value, @"(?:ed|ing)$", Rx) || Regex.IsMatch(before, @"\b(?:used|cast|missed|wasted)\s+(?:(?:his|her|their)\s+)?$", Rx));
        // In "he is ulting on Ahri", Ahri is the recipient, not the ultimate owner.
        if (thirdPersonCast) local = local.Where(m => m.Index < match.Index).ToArray();
        var named = local.Select(m => m.Player).DistinctBy(PlayerKey).ToArray();
        if (named.Length > 1)
        {
            // A conjunction separates targets only when each side has a spell predicate.
            int start = bounds.Start, end = bounds.End;
            string spellWords = @"\b(?:flash(?:ed)?|teleport|tp|ignite|exhaust|cleanse|ghost|barrier|heal|smite|ult(?:imate|i|ed|ing)?|r)\b";
            foreach (Match c in Regex.Matches(clause, @"[,;]|\b(?:and|but)\b", Rx))
            {
                int index = bounds.Start + c.Index;
                if (!Regex.IsMatch(text[bounds.Start..index], spellWords, Rx) ||
                    !Regex.IsMatch(text[(index + c.Length)..bounds.End], spellWords, Rx)) continue;
                if (index < match.Index) start = index + c.Length; else { end = index; break; }
            }
            local = local.Where(m => m.Index >= start && m.Index < end).ToArray();
            named = local.Select(m => m.Player).DistinctBy(PlayerKey).ToArray();
        }
        if (named.Length == 1)
        {
            var mention = local.First(m => PlayerKey(m.Player) == PlayerKey(named[0]));
            return new(named[0], "explicit", "Named champion/player or unambiguous side-qualified role: " + mention.Source + ".", mention.Time);
        }
        if (named.Length > 1 || local.Length > 0) return null;
        // A unique named ultimate can itself identify its owner; generic ult/R cannot.
        if (abilityOwner is not null) return new(abilityOwner, "ability", "Ultimate name uniquely identifies a champion in this game.", at);
        bool pronoun = Regex.IsMatch(clause, @"\b(?:he|she|his|her|him|they|their)\b", Rx);
        bool elliptical = Regex.IsMatch(clause, @"^\s*(?:(?:yeah|oh|well|okay)[, ]+)*(?:no|without)\b", Rx);
        if ((pronoun || elliptical) && u.Speaker.Length > 0 && subjects.TryGetValue(u.Speaker, out var subject) &&
            subject.Resolution.Player.Role != "team" &&
            !(pronoun && subject.Resolution.IsSelf) &&
            at >= subject.Last && at - subject.Last <= RepeatSeconds && at - subject.Resolution.AnchorTime <= ContextSeconds + RepeatSeconds)
        {
            var competing = history.Where(f => f.Time > subject.Last && f.Time <= at).Select(f => PlayerKey(f.Player)).Distinct().ToArray();
            if (competing.All(k => k == PlayerKey(subject.Resolution.Player)))
                return subject.Resolution with { Method = "same-speaker context", Evidence = "Same speaker continues the recently resolved target. " + subject.Resolution.Evidence };
        }
        if (!pronoun) return null;
        var recent = history.Where(f => f.Player.Role != "team" && f.Time <= at && at - f.End <= ContextSeconds).ToArray();
        var candidates = recent.Select(f => f.Player).DistinctBy(PlayerKey).ToArray();
        if (candidates.Length == 1)
        {
            var source = recent.OrderByDescending(f => f.Time).First();
            return new(candidates[0], "local context", $"Unambiguous topic within {ContextSeconds:0}s of the supporting statement: “{source.Text}” (audio {source.Time:F2}s).", Math.Min(at, source.End));
        }
        if (candidates.Length > 1) return null;
        // Lane context is weaker than a named target: require a recent gank/look proposal AND
        // a response from that lane's player. A bare geographical mid/top/bot word is insufficient.
        string ownRole = CommsSpeechIntervals.AssignedRole(u.Speaker, roles);
        var relevant = lanes.Where(l => l.Time <= at && at - l.Time <= ContextSeconds && l.Role == ownRole).ToArray();
        var opponents = players.Where(p => p.Ally == false && p.Role == ownRole).ToArray();
        if (relevant.Length > 0 && opponents.Length == 1)
        {
            var lane = relevant[^1];
            return new(opponents[0], "lane response", "Lane player's status reply to recent gank/look proposal: “" + lane.Text + "”.", lane.Time);
        }
        return null;
    }

    private static Player TeamTarget(bool ally, List<Player> players)
    {
        var teams = players.Where(p => p.Ally == ally).Select(p => p.Team).Distinct().ToArray();
        return new Player { Champion = ally ? "Allied team" : "Enemy team", Role = "team", Ally = ally,
            Team = teams.Length == 1 ? teams[0] : ally ? -2 : -1, Generic = true };
    }

    private static (bool Applies, Resolution? Resolution) ResolveGroup(Utterance u, SpellMention spell,
        (int Start, int End) bounds, List<Player> players, List<Focus> history)
    {
        string clause = u.Text[bounds.Start..bounds.End];
        string owner = u.Text[bounds.Start..spell.Match.Index];
        if (Regex.IsMatch(owner, @"\bmy\s*$|\bi(?:'ve|'m| am)?\s+(?:(?:just|already|still|another|had|to|have|got|used|missed|wasted|burned|burnt|cast|no|not|don't|do not|an?|the)\s+)*$", Rx)) return (false, null);
        bool enemy = Regex.IsMatch(clause, @"\b(?:enemy|opposing|their)\s+(?:team|bot\s*lane|duo)\b", Rx);
        bool ally = Regex.IsMatch(clause, @"\b(?:our|allied|my)\s+(?:team(?:mates)?|bot\s*lane|duo)\b|^\s*(?:(?:yeah|okay|well)[, ]+)*we(?:'ve| have| got| don't| do not)\b", Rx);
        bool pluralThey = Regex.IsMatch(clause, @"^\s*(?:(?:yeah|okay|well|oh)[, ]+)*they(?:'ve| have| got| don't| do not| used| burned)\b", Rx);
        bool pluralSpell = spell.Bundle || Regex.IsMatch(spell.Match.Value, @"(?:flashes|ults|ultimates)$", Rx);
        if (!enemy && !ally && !(pluralThey && pluralSpell)) return (false, null);
        if (enemy && ally) return (true, null);
        double at = u.At(spell.Match.Index).Word.Start;
        if (!enemy && !ally)
        {
            var sides = history.Where(f => f.Time <= at && at - f.End <= ContextSeconds && f.Player.Ally.HasValue)
                .Select(f => f.Player.Ally!.Value).Distinct().ToArray();
            if (sides.Length > 1) return (true, null);
            ally = sides.Length == 1 && sides[0];
            enemy = !ally;
        }
        return (true, new Resolution(TeamTarget(ally, players), "team group",
            ally ? "Explicit allied plural/team reference; counted once without assigning individual spell owners."
                : "Opposing-team plural/team shorthand; counted once without inventing individual spell owners.", at));
    }

    private static string FindingScope(Utterance u, Resolution resolution, List<Player> players,
        IReadOnlyDictionary<string, string> roles)
    {
        if (resolution.IsSelf) return "Self";
        var target = resolution.Player;
        if (target.Ally == false) return "Enemy";
        if (target.Ally != true) return "Unknown";
        string role = CommsSpeechIntervals.AssignedRole(u.Speaker, roles);
        var own = players.Where(p => p.Ally == true && p.Role == role && role != "unknown").ToArray();
        return own.Length == 1 && PlayerKey(own[0]) == PlayerKey(target) ? "Self" : "Ally";
    }

    private static (string Role, string Method) CallSpeaker(Utterance u, IReadOnlyDictionary<string, string> roles)
    {
        string role = CommsSpeechIntervals.AssignedRole(u.Speaker, roles);
        if (u.Speaker.Length == 0 || u.Tokens.Any(t => UnknownSpeaker(t.Speaker)))
            return (u.Overlap ? "overlap" : "unknown", "unresolved fragment attribution");
        if (!u.Overlap) return (role, "consistent word speaker");
        int anchors = u.Tokens.Count(t => !t.Word.OverlappingSpeech && CommsSpeechIntervals.IsTimedWord(t.Word) &&
            !Regex.IsMatch(t.Text, @"^(?:yeah|yes|okay|ok|well|oh|ah|um|uh|hmm)[,.!?]*$", Rx));
        return anchors >= 2 ? (role, "consistent speaker with non-overlap word anchors") : ("overlap", "unresolved overlapping speaker");
    }

    private static string TrackingFacts(string text) => string.Join("|", Regex.Matches(text,
        @"\b(?:top(?:\s*side)?|mid(?:lane)?|bot(?:\s*side|tom)?|river|blue|red|wolves|raptors|krugs|gromp|scuttle|crab|dragon|drake|baron|herald|grubs|here|there|missing|gank(?:ing|ed)?|path(?:ing)?|clear(?:ing)?|recall(?:ing|ed)?|freez(?:e|ing)|(?:three|3)[ -]?camp(?:ed|ing)?)\b", Rx)
        .Cast<Match>().Select(m => Regex.Replace(m.Value.ToLowerInvariant(), @"\s+", "")).Distinct().OrderBy(s => s, StringComparer.Ordinal));

    private static (string Text, string Kind)? TrackingPredicate(string clause)
    {
        if (Question(clause) || Regex.IsMatch(clause, @"^\s*(?:if|can|could|please|let's|lets)\b", Rx) ||
            Regex.IsMatch(clause, @"\b(?:want|need|would like)\s+(?:him|her|them|\w+(?:\s+\w+)?)\s+(?:here|there|to)\b", Rx) ||
            Regex.IsMatch(clause, @"\b(?:i|we)\s+(?:want|need|wanna|will|can|should|could)\b|\b(?:skin|chroma|emote)\b", Rx)) return null;
        string? kind = null;
        bool camp = Regex.IsMatch(clause, @"\b(?:wolves|raptors|krugs|gromp|scuttle|crab|dragon|drake|baron|herald|grubs)\b|\b(?:on|at|taking|clearing|stealing|invading)\s+(?:(?:his|her|their|our|the)\s+)?(?:blue|red)(?:\s+buff)?\b|\b(?:blue|red)\s+(?:buff|camp)\b", Rx);
        bool zone = Regex.IsMatch(clause, @"\b(?:top\s*side|bot\s*side|bottom\s*side|blue\s*side|red\s*side|river|tri[- ]?bush|jungle entrance)\b", Rx);
        bool movement = Regex.IsMatch(clause, @"\b(?:pathing|rotating|heading|moving|walking|crossing)\b", Rx) &&
            Regex.IsMatch(clause, @"\b(?:to|toward|towards|through|from|into|across)\b", Rx) &&
            Regex.IsMatch(clause, @"\b(?:top|mid|bot|bottom|river|jungle|blue|red|base|dragon|baron)\b", Rx);
        bool jungleActivity = Regex.IsMatch(clause, @"\b(?:(?:three|3)[ -]?camp(?:ed|ing)?|skipping\s+camps|counter[- ]?jungl(?:e|ing)|invad(?:e|ing))\b", Rx);
        bool inferred = Regex.IsMatch(clause, @"\b(?:should\s+be|must\s+be|probably|likely)\b", Rx) &&
            Regex.IsMatch(clause, @"\b(?:top|mid|bot|bottom|base|jungle)\b", Rx);
        if (camp) kind = "Camp or objective";
        else if (movement) kind = "Route or rotation";
        else if (jungleActivity) kind = "Jungle activity";
        else if (zone || inferred) kind = "Map position or inference";
        if (kind is null) return null;
        // A bare lane sighting, gank on the caller, wave help, here/there or missing call
        // does not establish route/camp/map tracking by itself.
        return (clause.Trim().TrimEnd('.', '!', '?'), kind);
    }

    private static List<CommsAnalysisFinding> DetectCallouts(IEnumerable<WordResult> words,
        IReadOnlyDictionary<string, string> roles, List<Player> players, LeagueAliasCatalog catalog,
        double? offset, double? duration, CancellationToken token)
    {
        var utterances = JoinFragments(DetectionUtterances(words), players);
        var history = new List<Focus>();
        var lanes = new List<LaneFocus>();
        var subjects = new Dictionary<string, (Resolution Resolution, double Last)>(StringComparer.Ordinal);
        var findings = new List<CommsAnalysisFinding>();
        var last = new Dictionary<string, CommsAnalysisFinding>(StringComparer.Ordinal);
        // Compound ability+Flash shorthand may ground a following pronoun, but is not
        // automatically a cast. Owners and aliases come from the current roster/catalog.
        var signatures = players.SelectMany(p => catalog.Abilities(p.ChampionId).Where(a => a.Slot == "R")
            .SelectMany(a => catalog.Names(a, a.Name)).Where(n => n.Length >= 4 && !n.Contains(' '))
            .Select(n => (Player: p, Name: n)))
            .GroupBy(p => p.Name, StringComparer.OrdinalIgnoreCase).Where(g => g.Select(p => PlayerKey(p.Player)).Distinct().Count() == 1)
            .Select(g => g.First()).ToArray();
        foreach (var u in utterances)
        {
            token.ThrowIfCancellationRequested();
            history.RemoveAll(f => f.End < u.Start - ContextSeconds);
            lanes.RemoveAll(l => l.Time < u.Start - ContextSeconds);
            var mentions = Mentions(u, players);
            string text = u.Text;
            var spells = SpellMentions(text, players, catalog).OrderBy(s => s.Match.Index).ThenByDescending(s => s.Match.Length)
                .DistinctBy(s => (s.Match.Index, s.Category, s.Name)).ToArray();
            CallState? inherited = null;
            SpellMention? previous = null;
            Resolution? previousTarget = null;
            foreach (var spell in spells)
            {
                var bounds = ClauseBounds(text, spell.Match);
                string clause = text[bounds.Start..bounds.End];
                string before = text[bounds.Start..spell.Match.Index];
                string after = text[(spell.Match.Index + spell.Match.Length)..bounds.End];
                var state = State(text, spell, clause, before, after);
                if (state is null && previous is not null && inherited is not null && previousTarget is not null &&
                    previous.Match.Index >= bounds.Start && previous.Match.Index + previous.Match.Length <= spell.Match.Index &&
                    Regex.IsMatch(text[(previous.Match.Index + previous.Match.Length)..spell.Match.Index], @"^(?:\s|,|and\b|or\b|no\b|my\b|his\b|her\b|their\b)+$", Rx)) state = inherited;
                var group = ResolveGroup(u, spell, bounds, players, history);
                var resolution = group.Applies ? group.Resolution : Resolve(u, spell.Match, bounds, mentions, players, roles, history, subjects, lanes, spell.AbilityOwner);
                if (!group.Applies && state is not null && resolution is null && previousTarget is not null && inherited == state &&
                    previous is not null && previous.Match.Index >= bounds.Start) resolution = previousTarget;
                if (state is not null && resolution is not null)
                {
                    bool ordinaryWord = spell.NeedsContext && state.Kind == "used" &&
                        !Regex.IsMatch(clause, @"\bsummoner(?:s| spell)?\b", Rx) &&
                        !Regex.IsMatch(before, @"\b(?:used|burned|burnt|my|his|her|their)\s*$", Rx);
                    int? spellId = spell.Category == "Summoner" && !spell.Bundle ? catalog.Summoner(null, spell.Name)?.Id : null;
                    bool impossibleSelfCast = resolution.IsSelf && state.Kind == "used" && spellId.HasValue &&
                        resolution.Player.SpellIds.Count == 2 && !resolution.Player.SpellIds.Contains(spellId.Value);
                    if (!ordinaryWord && !impossibleSelfCast)
                        AddFinding(u, spell.Match.Index, spell.Category, spell.Name, state, resolution, spell.Bundle);
                }
                previous = spell; inherited = state; previousTarget = resolution;
            }
            if (offset.HasValue)
            {
                // Tracking is evaluated per sentence, with local mention and time grounding.
                foreach (Match sentence in Regex.Matches(text, @"[^.!?;]+[.!?;]?", Rx))
                {
                    string clause = sentence.Value;
                    var predicate = TrackingPredicate(clause);
                    if (predicate is not { } tracking) continue;
                    var local = mentions.Where(m => m.Index >= sentence.Index && m.Index < sentence.Index + sentence.Length).ToArray();
                    var target = local.Select(m => m.Player).DistinctBy(PlayerKey).ToArray();
                    Resolution? resolution = null;
                    int index = sentence.Index;
                    if (target.Length == 1 && target[0].Ally == false && target[0].Role == "jungle")
                    {
                        var m = local[0]; index = m.Index;
                        resolution = new(target[0], "explicit", "Explicit enemy jungler plus location/activity.", m.Time);
                    }
                    else if (target.Length == 0)
                    {
                        var pronoun = Regex.Match(clause, @"\b(?:he|she|they|his|her|their)\b", Rx);
                        if (pronoun.Success)
                        {
                            index = sentence.Index + pronoun.Index;
                            // Resolve expects an index in the utterance, so find the same token at its absolute position.
                            var absolute = Regex.Matches(text, @"\b\w+\b").Cast<Match>().First(m => m.Index == index);
                            resolution = Resolve(u, absolute, (sentence.Index, sentence.Index + sentence.Length), mentions, players, roles, history, subjects, lanes);
                        }
                    }
                    if (resolution is not null && resolution.Player.Ally == false && resolution.Player.Role == "jungle")
                    {
                        double game = u.At(index).Word.Start + offset.Value;
                        if (game >= 0 && game < 900)
                            AddFinding(u, index, "Jungle <15:00", "Tracking", new("tracking", tracking.Text), resolution, false, tracking.Kind);
                    }
                }
            }
            // Publish identity evidence only; an inferred pronoun does not extend its own global expiry.
            foreach (var m in mentions) history.Add(new(m.Player, m.Time, u.End, text, u.Speaker));
            foreach (Match team in Regex.Matches(text, @"\b(?<side>our|allied|my|enemy|opposing|their)\s+(?:team(?:mates)?|bot\s*lane|duo)\b", Rx))
                history.Add(new(TeamTarget(Regex.IsMatch(team.Groups["side"].Value, @"^(?:our|allied|my)$", Rx), players), u.At(team.Index).Word.Start, u.End, text, u.Speaker));
            foreach (var signature in signatures)
                foreach (Match m in Regex.Matches(text, Phrase(signature.Name + "flash"), Rx))
                    history.Add(new(signature.Player, u.At(m.Index).Word.Start, u.End, text, u.Speaker));
            foreach (Match m in Regex.Matches(text, @"\b(?:look(?:ing)?(?:\s+at)?|gank(?:ing)?|dive)\s+(?<lane>top|mid|bot|bottom)\b", Rx))
                lanes.Add(new(m.Groups["lane"].Value is "bot" or "bottom" ? "adc" : m.Groups["lane"].Value.ToLowerInvariant(), u.At(m.Index).Word.Start, text));
        }
        return findings.OrderBy(f => f.AudioSeconds).ThenBy(f => f.Category, StringComparer.Ordinal).ToList();

        void AddFinding(Utterance u, int index, string category, string spell, CallState state, Resolution resolution, bool bundle, string trackingKind = "")
        {
            double at = u.At(index).Word.Start;
            var p = resolution.Player;
            var attribution = CallSpeaker(u, roles);
            string role = attribution.Role;
            var finding = new CommsAnalysisFinding
            {
                AudioSeconds = at, GameSeconds = offset.HasValue ? at + offset.Value : null, Role = role, SpeakerId = u.Speaker, SpeakerAttribution = attribution.Method,
                Category = category, Spell = spell, Target = p.Champion, TargetResolution = resolution.Method,
                Scope = FindingScope(u, resolution, players, roles), TargetIsGroup = p.Role == "team", TrackingKind = trackingKind,
                Call = state.Label, CallKind = state.Kind, TimerSeconds = state.Seconds, GenericSummonerBundle = bundle,
                Text = u.Text, UsesCollapsedTiming = u.Collapsed,
                Uncertain = Regex.IsMatch(u.Text, @"\b(?:think|maybe|might|probably|perhaps|should|not sure)\b", Rx),
            };
            if (!InGame(finding, duration)) return;
            string identity = u.Identity.Length > 0 ? u.Identity : "unknown:" + u.Start.ToString("R", CultureInfo.InvariantCulture);
            string key = identity + "|" + PlayerKey(p) + "|" + category + "|" + spell;
            if (category == "Summoner")
            {
                string prefix = identity + "|" + PlayerKey(p) + "|Summoner|";
                var related = last.Where(pair => pair.Key.StartsWith(prefix, StringComparison.Ordinal) &&
                    at >= pair.Value.AudioSeconds && at - pair.Value.AudioSeconds <= RepeatSeconds && pair.Value.CallKind == state.Kind).ToArray();
                if (bundle && related.Any(pair => !pair.Value.GenericSummonerBundle)) return;
                if (!bundle)
                    foreach (var pair in related.Where(pair => pair.Value.GenericSummonerBundle))
                    { findings.Remove(pair.Value); last.Remove(pair.Key); }
            }
            if (last.TryGetValue(key, out var prior) && at >= prior.AudioSeconds && at - prior.AudioSeconds <= RepeatSeconds &&
                (category == "Jungle <15:00" && TrackingFacts(prior.Call) == TrackingFacts(state.Label) ||
                    category != "Jungle <15:00" && prior.CallKind == state.Kind &&
                    (state.Kind is not ("cooldown" or "clock") || prior.TimerSeconds == state.Seconds || state.Kind == "cooldown" &&
                        Math.Abs(prior.AudioSeconds + (prior.TimerSeconds ?? 0) - at - (state.Seconds ?? 0)) <= 2)))
            {
                if (!prior.Text.Contains(u.Text, StringComparison.Ordinal)) prior.Text += "\n" + u.Text;
                prior.UsesCollapsedTiming |= u.Collapsed;
                return;
            }
            finding.Subject = p.Champion + " · " + (category == "Jungle <15:00" ? state.Label : spell + " · called " + state.Label.ToLowerInvariant());
            finding.Evidence = "Callout scope: " + ScopeName(finding.Scope) + ". " + resolution.Evidence + " Availability/location describes what was said; saved data does not verify its correctness.";
            if (trackingKind.Length > 0) finding.Evidence += " Tracking basis: " + trackingKind + ".";
            if (u.Overlap) finding.Evidence += " Speaker attribution: " + attribution.Method + ". This call is counted once, never copied to all overlap candidates.";
            if (finding.Uncertain) finding.Evidence += " The speaker expressed uncertainty.";
            if (u.Collapsed) finding.Evidence += " Some supporting words have collapsed timing; no speech duration was added.";
            if (bundle) finding.Evidence += " Unspecified summoner bundle counts once; individual spells are not invented.";
            finding.Id = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(at.ToString("R", CultureInfo.InvariantCulture) + "|" + key + "|" + state.Kind)))[..24];
            findings.Add(finding); last[key] = finding;
            if (u.Speaker.Length > 0) subjects[u.Speaker] = (resolution, at);
        }
    }
}
